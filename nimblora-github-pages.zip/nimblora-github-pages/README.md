# Nimblora — GitHub Pages launch package

A responsive landing page for a website and AI automation service.

## 1. Connect the waitlist

Open `config.js` and replace `REPLACE_WITH_YOUR_EMAIL` with the email address that should receive signups:

```js
window.NIMBLORA_CONFIG = {
  formEndpoint: "https://formsubmit.co/hello@example.com"
};
```

The first real submission triggers a confirmation email from FormSubmit. Confirm it once; later submissions will then arrive in the configured inbox. No FormSubmit account is required.

## 2. Publish on GitHub Pages

1. Create a new **public** GitHub repository named `nimblora-landing`.
2. Upload all files and folders from this package and commit them to `main`.
3. Open **Settings → Pages**.
4. Under **Build and deployment → Source**, select **GitHub Actions**.
5. Open the **Actions** tab and wait for “Deploy Nimblora to GitHub Pages” to finish.

The site address will normally be:

`https://YOUR-GITHUB-USERNAME.github.io/nimblora-landing/`

Every later commit to `main` redeploys automatically.

## Brand

- **Name:** Nimblora
- **Tagline:** Websites that sell. Systems that scale.
- **Positioning:** Conversion-focused websites and practical AI automation for service businesses.

## Local preview

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

## Naming note

Before registering the business or buying a domain, perform proper company-name, trademark, and domain checks in your market.
